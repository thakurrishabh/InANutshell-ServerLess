import boto3

def uploadToS3(filename,bucket_name):
    s3=boto3.client("s3")
    s3.upload_file('/tmp/' + filename, bucket_name, filename)