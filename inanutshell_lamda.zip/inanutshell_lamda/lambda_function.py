import boto3
import os
from contextlib import closing
import requests
from textsummarizer import summarizeText
from helper import uploadToS3
from pdfminer.high_level import extract_text

def uploadToS3Binary(filename,bucket_name,ext):
    s3=boto3.client("s3")
    s3.upload_file('/tmp/' + filename, bucket_name, filename + '.'+ext)

def uploadToS3BinaryWithDifferentName(inputfilename,outputfilename,bucket_name,ext):
    s3=boto3.client("s3")
    s3.upload_file('/tmp/' + inputfilename, bucket_name, outputfilename + '.'+ext)


def textToAudio(file_content,filename):
    polly_client = boto3.client('polly')
    response = polly_client.synthesize_speech(VoiceId='Joanna',
                OutputFormat='mp3',
                Text=file_content)

    with closing(response["AudioStream"]) as stream:
        output = os.path.join("/tmp/", filename)
        with open(output, "wb") as file:
            file.write(stream.read())
    uploadToS3Binary(filename,"inanutshell-mediafiles","mp3")

def textExtractFromTxt(filePath):
    with open(filePath,"r") as file:
        file_content=file.read()
    return file_content

def textExtractFromPDF(filePath):
    os.environ['PATH']=":"+"./bin"

    file_content = extract_text(filePath)
    print("file_content:"+file_content)
    return file_content


def gets3object(file_obj,bucket_name):
    s3_resource = boto3.resource('s3')
    filestring=str(file_obj['s3']['object']['key'])
    filePath='/tmp/'+filestring
    s3_resource.Object(bucket_name, filestring).download_file(
    f'/tmp/'+filestring)

    completefilename=filestring.split('.')
    file_extension=completefilename[1]
    print(file_extension)
    if(file_extension=="txt"):
        file_content = textExtractFromTxt(filePath)
    elif(file_extension=="pdf"):
        file_content = textExtractFromPDF(filePath)

    return file_content,completefilename[0], file_extension

def lambda_handler(event, context):
    s3=boto3.client("s3")
    if event:
        file_obj= event["Records"][0]
        (file_content,filename, file_extension)=gets3object(file_obj,file_obj['s3']['bucket']['name'])

        if(len(file_content)>2900):
            file_content_exceeded="Document exceeds our 3000 word limit. Couldn't generate audio file using Amazon Polly"
            textToAudio(file_content_exceeded,filename)
        else:
            textToAudio(file_content,filename)
        #summarization takes place below

        summary_file_name=filename+"_summarized"
        summarized_content=summarizeText(file_content,summary_file_name,filename+'.'+file_extension)
        uploadToS3(summary_file_name+".txt","inanutshell-summarizedtextfiles")

        textToAudio(summarized_content,summary_file_name)
