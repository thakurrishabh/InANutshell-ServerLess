import requests
import json

def get_taxonomy( text ):
	api_key  = ""
	response = requests.post( "https://apis.paralleldots.com/v4/taxonomy", data= { "api_key": api_key, "text": text } ).text
	response = json.loads(response)
	return response

def get_tag(text):
	#text      = "A Toronto chemical engineering professor has won the $1 million Gerhard Herzberg Canada Gold Medal, the country's top science prize, for her work designing gels that mimic human tissues."
	
	print( "\nTaxonomy" )
	response = get_taxonomy( text ) 
	print(response)
	
	
	res_in=list(response.values())[0][0]
	print(res_in)
	tag=res_in['tag']
	
	print(tag)
	return tag