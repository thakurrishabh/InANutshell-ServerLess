from pdfminer.high_level import extract_text
import os
import docx
from pptx import Presentation

def textExtractFromPDF(filePath):
    os.environ['PATH']=":"+"./bin"

    file_content = extract_text(filePath)
    print("file_content:"+file_content)
    return file_content

def textExtractFromDOCX(filePath):
    doc = docx.Document(filePath)
    file_content = []
    for para in doc.paragraphs:
        file_content.append(para.text)
    return '\n'.join(file_content)

def textExtractFromPPTX(filePath):
    prs = Presentation(filePath)
    file_content=""
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                file_content=file_content+" "+shape.text
                print(shape.text)
    return file_content

print(textExtractFromPDF("AItextsummary_new9.pdf"))
