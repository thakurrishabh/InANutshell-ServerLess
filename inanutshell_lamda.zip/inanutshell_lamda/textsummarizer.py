import requests
from helper import uploadToS3
from update_tag import update_tags
from paralleldots_api import get_tag
import os


def summarizeText(file_content,filename,completefilename, summary_percentage=10):
    API_KEY = ""
    API_ENDPOINT = "https://api.smmry.com"

    data = {
        "sm_api_input":file_content
    }

    sum_length=str(int(((len(file_content)/50)*summary_percentage)/100))

    if(int(sum_length)<3):
        sum_length="3"
    elif(int(sum_length)>8):
        sum_length="8"
    print(sum_length)
    params = {
        "SM_API_KEY":API_KEY,
        "SM_LENGTH": sum_length
    }
    header_params = {"Expect":"100-continue"}
    r = requests.post(url=API_ENDPOINT, params=params, data=data, headers=header_params)
    r= r.json()

    if "sm_api_content" not in r:
        text_to_write=file_content
    else:
        text_to_write=r["sm_api_content"]

    with open(os.path.join("/tmp/",filename+".txt"),"w+") as file:
        file.write(text_to_write)

    uploadToS3(filename+".txt","inanutshell-summarizedtextfiles")
    up_tag=get_tag(text_to_write)
    print(completefilename)
    update_tags(completefilename, 'tag', up_tag)
    update_tags(completefilename, 'summary', text_to_write)
    intro="file, "+completefilename.split('.')[0]+ "."+" topic, "+up_tag+". "
    return intro+text_to_write
