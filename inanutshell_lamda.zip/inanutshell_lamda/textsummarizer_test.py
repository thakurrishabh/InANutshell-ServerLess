import requests
import os
import PyPDF2

def summarizeText(file_content,filename, summary_percentage=10):
    API_KEY = ""
    API_ENDPOINT = "https://api.smmry.com"

    data = {
        "sm_api_input":file_content
    }

    sum_length=str(int(((len(file_content)/50)*summary_percentage)/100))

    if(int(sum_length)<3):
        sum_length="3"
    elif(int(sum_length)>8):
        sum_length="8"
    print(sum_length)
    params = {
        "SM_API_KEY":API_KEY,
        "SM_LENGTH": sum_length
    }
    header_params = {"Expect":"100-continue"}
    r = requests.post(url=API_ENDPOINT, params=params, data=data, headers=header_params)
    r= r.json()

    if "sm_api_content" not in r:
        text_to_write=file_content
    else:
        text_to_write=r["sm_api_content"]

    return text_to_write


import PyPDF2
pdfFileObj = open('Assignment1.pdf', 'rb')
pdfReader = PyPDF2.PdfFileReader(pdfFileObj)

file_content=""
for pageNo in range(0,pdfReader.numPages):
    pageObj = pdfReader.getPage(pageNo)
    file_content=file_content+pageObj.extractText()
