import pymongo
import copy

def findAll(SampleTable):
    query = SampleTable.find()
    output = {}
    i = 0
    for x in query:
        output[i] = x
        output[i].pop('_id')
        i += 1
    return (output)

def findOne(FullTable,argument, value):
    queryObject = {argument: value}
    query = FullTable.find_one(queryObject)
    query.pop('_id')
    return query

def update(FullTable,mydoc, newdoc):

    query = FullTable.update_one(mydoc, {'$set': newdoc})
    if query.acknowledged:
        return "Update Successful"
    else:
        return "Update Unsuccessful"

def update_tags(file_name,tag_key,tag_up):
    connection_url = 'mongodb+srv://username:password@inanutshellcluster.e1yvh.mongodb.net/InANutShell_DB?retryWrites=true&w=majority'
    print(file_name)
    client = pymongo.MongoClient(connection_url)

    # Database
    Database = client.get_database('InANutShell_DB')
    # Table
    FullTable = Database.inanutshell_app_files

    # mycol = Database["inanutshell_app_files"]
    #myquery = { "docs": "test8.txt" }

    mydoc = findOne(FullTable,"docs", file_name)

    newdoc=copy.deepcopy(mydoc)
    newdoc[tag_key]=tag_up
    updatedoc = update(FullTable,mydoc, newdoc)

    #print(findAll(SampleTable))
    print(mydoc)
    print(newdoc)
    print(updatedoc)
